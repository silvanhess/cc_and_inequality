# wrapper for running the population disaggregation function
from disaggregate_population import disaggregate_population

### run population disaggregation
disaggregate_population()